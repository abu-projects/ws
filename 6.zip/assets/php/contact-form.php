<?php
    $name = $_POST['name'];
    $familyName = $_POST['family-namee'];
    $mobile = $_POST['Mobile'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $to = 'yapepo@gmail.com';

    $body = "From: $name $familyName <br> Mobile: $mobile <br> E-Mail: $email <br> Message: <br> $message";

    // Email headers...

    mail($to, "New Message from Website: $subject", $body, $headers);
?>